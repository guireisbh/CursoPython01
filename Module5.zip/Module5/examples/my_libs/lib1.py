# Демонстрационный модуль
def do_something():
    return "I'm func do_something in module lib1"

def more_then_one(num):
    return num > 1
