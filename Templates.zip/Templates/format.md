```python
x = True
y = False
print('bool --> ', x, '/', y)
print("1 + True = ", 1 + True)  # True, по сути, и есть 1
```

---

---

```python

```

<details>
<summary>Abstract</summary>
Here are the details.
</details>


|  |  |  |
| -- | -- | -- |
|  |  |  |
|  |  |  |

🚀️

- [X]  Examine code
- [X]  Commit fixes
- [X]  Request a review

![board](img/board.png)
